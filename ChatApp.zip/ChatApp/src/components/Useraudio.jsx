import React from 'react'

function Useraudio() {
  return (
    <>
      <div className=" w-ful pl-[3.6vw] flex">
        <audio className='w-[16.1vw] h-[2.9vw]' controls src=""></audio>
      </div>
    </>
  )
}

export default Useraudio
